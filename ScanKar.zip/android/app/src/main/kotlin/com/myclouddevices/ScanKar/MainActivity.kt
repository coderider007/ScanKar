package com.myclouddevices.ScanKar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
