class Constants {
  static const appTitle = 'ScanKar';
  static const ROUTE_HOME = '/';
  static const ROUTE_SCAN_NEW = '/scan';
  static const ROUTE_PAGES_IN_FILE = '/currentfile';
}
